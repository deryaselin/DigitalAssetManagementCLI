package com.example.enums;

/** CommandType. */
public enum CommandType {
  SAVE("save"),
  UPDATE("update"),
  DELETE("delete"),
  SEARCH("search"),
  LIST("list"),
  HELP("help");

  private String value;

  CommandType(String value) {
    this.value = value;
  }

  /**
   * Returns command type associated with given value.
   *
   * @param value command id
   * @return command type associated with given value, or null if association not found.
   */
  public static CommandType getByValue(String value) {
    for (CommandType command : CommandType.values()) {
      if (command.value.equals(value)) {
        return command;
      }
    }
    return null;
  }
}

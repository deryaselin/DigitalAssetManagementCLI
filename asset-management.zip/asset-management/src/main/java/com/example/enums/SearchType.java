package com.example.enums;

/** SearchType. */
public enum SearchType {
  BY_NAME("name"),
  BY_TYPE("type"),
  BY_TAG("tag");

  private String value;

  SearchType(String value) {
    this.value = value;
  }

  /**
   * Returns search type associated with given value.
   *
   * @param value the value
   * @return search type associated with given value, or null if association not found.
   */
  public static SearchType getByValue(String value) {
    for (SearchType searchType : SearchType.values()) {
      if (searchType.value.equals(value)) {
        return searchType;
      }
    }
    return null;
  }
}

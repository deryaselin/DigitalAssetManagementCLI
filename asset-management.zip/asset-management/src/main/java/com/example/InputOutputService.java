package com.example;

import com.example.enums.CommandType;
import com.example.enums.SearchType;
import com.example.model.Command;
import com.example.utils.JsonUtils;
import org.apache.commons.cli.*;

/** InputOutputService. */
public class InputOutputService {

  private Options options = new Options();

  public InputOutputService() {
    this.options = createOptions();
  }

  /**
   * Parses arguments based on predefined options.
   *
   * @param args the args
   * @return a parsed command object.
   * @throws ParseException
   */
  public Command parse(String[] args) {

    CommandLineParser commandLineParser = new DefaultParser();
    CommandLine commandLine = null;

    try {
      commandLine = commandLineParser.parse(options, args);
    } catch (ParseException ex) {
      printMessage(ex.getMessage());
      printHelpMessage();
    }

    Command command = new Command();

    String commandTypeAsStr = commandLine.getOptionValue("command");
    command.setCommandType(CommandType.getByValue(commandTypeAsStr));

    if (commandLine.hasOption("id")) {
      String id = commandLine.getOptionValue("id");
      command.setId(Integer.parseInt(id));
    }

    if (commandLine.hasOption("name")) {
      String name = commandLine.getOptionValue("name");
      command.setName(name);
    }

    if (commandLine.hasOption("type")) {
      String type = commandLine.getOptionValue("type");
      command.setType(type);
    }

    if (commandLine.hasOption("tags")) {
      String[] tags = commandLine.getOptionValues("tags");
      command.setTags(tags);
    }

    if (commandLine.hasOption("search-criteria")) {
      String searchCriteria = commandLine.getOptionValue("search-criteria");
      SearchType searchType = SearchType.getByValue(searchCriteria);
      command.setSearchType(searchType);
    }

    if (commandLine.hasOption("search-value")) {
      String searchValue = commandLine.getOptionValue("search-value");
      command.setSearchValue(searchValue);
    }

    return command;
  }

  /**
   * Creates options.
   *
   * @return the options.
   */
  private Options createOptions() {
    Option commandType =
        Option.builder()
            .option("command")
            .hasArg()
            .desc("The command type. It can be save, update, delete, search, list or help")
            .build();

    Option idOption = Option.builder().option("id").hasArg().desc("The name of the asset").build();

    Option nameOption =
        Option.builder().option("name").hasArg().desc("The name of the asset").build();

    Option typeOption =
        Option.builder().option("type").hasArg().desc("The type of the asset").build();

    Option tagOption =
        Option.builder().option("tags").hasArgs().desc("The tags of the asset").build();

    Option searchCriteriaOption =
        Option.builder()
            .option("search-criteria")
            .hasArg()
            .desc("Search criteria. It can be name, type or tag")
            .build();

    Option searchValueOption =
        Option.builder().option("search-value").hasArgs().desc("Search value.").build();

    Options options = new Options();
    options.addOption(commandType);
    options.addOption(idOption);
    options.addOption(nameOption);
    options.addOption(typeOption);
    options.addOption(tagOption);
    options.addOption(searchCriteriaOption);
    options.addOption(searchValueOption);
    return options;
  }

  /** Prints help message. */
  public void printHelpMessage() {
    HelpFormatter formatter = new HelpFormatter();
    formatter.printHelp(
        "[command save | update | delete | search | list | help] "
            + "[-id <id>] [-name <name>] [-type <type>] [-tags <tags>] "
            + "[-search-criteria <search-criteria> -search-value <search-value>]"
            + "\t Examples: \t 1) -command save -name Asset-1 -type Voice -tags Tag-1"
            + "\t2) -command update -id 1 -name New-Name -type Image -tags Tag-2"
            + "\t3) -command delete -id 1"
            + "\t4) -command search -search-criteria type -search-value Voice"
            + "\t5) -command list"
            + "\t6) -command help",
        options);
  }

  /**
   * Prints message.
   *
   * @param message message to be printed.
   */
  public void printMessage(String message) {
    System.out.println(message);
  }

  /**
   * Converts given object into json and prints it.
   *
   * @param object object to be printed as json string.
   */
  public void printAsJson(Object object) {
    String jsonStr = JsonUtils.toJson(object);
    System.out.println(jsonStr);
  }
}

package com.example.utils;

import com.google.gson.Gson;

import java.lang.reflect.Type;

/** JsonUtils */
public final class JsonUtils {

  private static final Gson GSON = new Gson();

  /** Don't let anyone create instance of this class. */
  private JsonUtils() {
    // NOOP
  }

  /** Serialize given object */
  public static String toJson(Object object) {
    return GSON.toJson(object);
  }

  /** Deserializes given json string. */
  public static <T> T parse(String jsonStr, Class<T> clazz) {
    return GSON.fromJson(jsonStr, clazz);
  }

  /** Deserializes given json string */
  public static <T> T parse(String jsonStr, Type type) {
    return GSON.fromJson(jsonStr, type);
  }
}

package com.example.utils;

import java.io.*;

/** FileUtils. */
public final class FileUtils {

  /** Don't let anyone create instance of this class. */
  private FileUtils() {
    // NOOP
  }

  /** Writes given content in given file. */
  public static void write(String fileName, String content) {
    File file = new File(fileName);
    PrintWriter printWriter = null;

    try {
      printWriter = new PrintWriter(new FileWriter(file));
      printWriter.print(content);
    } catch (IOException e) {
      throw new RuntimeException(e);
    } finally {
      if (printWriter != null) {
        printWriter.close();
      }
    }
  }

  /** Returns content of given file. */
  public static String read(String fileName) {
    File file = new File(fileName);

    if (!file.exists()) {
      return null;
    }

    StringBuilder sb = new StringBuilder();

    // maybe it's better to use try with resource.
    BufferedReader bufferedReader = null;
    try {
      bufferedReader = new BufferedReader(new FileReader(file));
      String line;
      while ((line = bufferedReader.readLine()) != null) {
        sb.append(line);
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    } finally {
      if (bufferedReader != null) {
        try {
          bufferedReader.close();
        } catch (IOException e) {
          throw new RuntimeException(e);
        }
      }
    }

    return sb.toString();
  }
}

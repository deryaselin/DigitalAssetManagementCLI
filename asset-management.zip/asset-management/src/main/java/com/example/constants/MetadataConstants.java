package com.example.constants;

/** MetadataConstants. */
public interface MetadataConstants {

  String SEQUENCE_CURRENT_VALUE = "SEQUENCE_CURRENT_VALUE";
}

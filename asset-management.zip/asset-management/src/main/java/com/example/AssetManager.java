package com.example;

import com.example.enums.SearchType;
import com.example.model.Asset;
import com.example.model.Command;
import org.apache.commons.cli.ParseException;

import java.util.Arrays;
import java.util.List;

/** Asset manager. */
public class AssetManager {

  private final InputOutputService inputOutputService;

  private final AssetRepository assetRepository;

  public AssetManager(InputOutputService inputOutputService, AssetRepository assetRepository) {
    this.inputOutputService = inputOutputService;
    this.assetRepository = assetRepository;
  }

  /** Starts app. */
  public void run(String[] args) {
    onStart();
    executeCommand(args);
    onExit();
  }

  /** Parses user command and dispatches it. */
  private void executeCommand(String[] args) {

    Command command = inputOutputService.parse(args);

    if (command.getCommandType() == null) {
      inputOutputService.printHelpMessage();
      return;
    }

    switch (command.getCommandType()) {
      case SAVE:
        onSave(command);
        break;
      case UPDATE:
        onUpdate(command);
        break;
      case DELETE:
        onDelete(command);
        break;
      case SEARCH:
        onSearch(command);
        break;
      case LIST:
        onList();
        break;
      case HELP:
        onHelp();
        break;
      default:
        inputOutputService.printMessage("Invalid command.");
        onHelp();
        break;
    }
  }

  /** Loads data into the memory. */
  private void onStart() {
    assetRepository.loadData();
  }

  /** Flushes data to the file. */
  private void onExit() {
    assetRepository.flush();
  }

  /** Saves asset */
  private void onSave(Command command) {

    if (command.getName() == null || command.getName().isEmpty()) {
      inputOutputService.printMessage("name is required while saving");
      return;
    }

    if (command.getType() == null || command.getType().isEmpty()) {
      inputOutputService.printMessage("type is required while saving");
      return;
    }

    Asset asset = new Asset();
    asset.setName(command.getName());
    asset.setType(command.getType());
    if (command.getTags() != null){
      asset.setTags(Arrays.asList(command.getTags()));
    }

    assetRepository.save(asset);
    inputOutputService.printMessage("Asset has been saved successfully!");
  }

  /** Updates asset. */
  private void onUpdate(Command command) {

    if (command.getId() == null) {
      inputOutputService.printMessage("id is required while saving");
      return;
    }

    Asset assetToBeUpdated = assetRepository.getById(command.getId());
    if (assetToBeUpdated == null) {
      inputOutputService.printMessage("Asset not found!");
      return;
    }

    if (command.getName() != null) {
      assetToBeUpdated.setName(command.getName());
    }

    if (command.getType() != null) {
      assetToBeUpdated.setType(command.getType());
    }

    if (command.getTags() != null) {
      assetToBeUpdated.setTags(Arrays.asList(command.getTags()));
    }

    assetRepository.update(assetToBeUpdated);
    inputOutputService.printMessage("Asset has been updated successfully!");
  }

  /** Deletes asset. */
  private void onDelete(Command command) {

    if (command.getId() == null) {
      inputOutputService.printMessage("id is required while deleting");
      return;
    }

    Asset assetToBeDeleted = assetRepository.getById(command.getId());
    if (assetToBeDeleted == null) {
      inputOutputService.printMessage("Asset not found!");
      return;
    }

    assetRepository.delete(assetToBeDeleted);
    inputOutputService.printMessage("Asset has been deleted successfully!");
  }

  /** Searches through assets. */
  private void onSearch(Command command) {

    SearchType searchType = command.getSearchType();
    String searchValue = command.getSearchValue();

    if (searchType == null) {
      inputOutputService.printMessage("search-criteria is required while searching");
      return;
    }

    if (searchValue == null) {
      inputOutputService.printMessage("search-value is required while searching");
      return;
    }

    List<Asset> filteredAssets = null;
    if (SearchType.BY_NAME.equals(searchType)) {
      filteredAssets = assetRepository.searchByName(searchValue);
    }

    if (SearchType.BY_TYPE.equals(searchType)) {
      filteredAssets = assetRepository.searchByType(searchValue);
    }

    if (SearchType.BY_TAG.equals(searchType)) {
      filteredAssets = assetRepository.searchByTag(searchValue);
    }

    inputOutputService.printMessage("----Filtered Assets----");
    filteredAssets.forEach(inputOutputService::printAsJson);
    inputOutputService.printMessage("-----------------------");
  }

  /** Lists all assets. */
  private void onList() {
    List<Asset> assets = assetRepository.getAll();
    inputOutputService.printMessage("----Assets----");
    assets.forEach(inputOutputService::printAsJson);
    inputOutputService.printMessage("--------------");
  }

  /** Prints help message. */
  private void onHelp() {
    inputOutputService.printHelpMessage();
  }
}

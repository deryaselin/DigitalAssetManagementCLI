package com.example;

import com.example.constants.MetadataConstants;
import com.example.model.Asset;
import com.example.model.Metadata;
import com.example.utils.FileUtils;
import com.example.utils.JsonUtils;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/** AssetRepository. */
public class AssetRepository {

  /** The name of the while in which assets are stored. */
  private static final String ASSETS_FILE_NAME = "assets.json";

  /** The name of the file in which metadata like sequence number are stored. */
  private static final String METADATA_FILE_NAME = "metadata.json";

  /** Map which stores assets. */
  private Map<Integer, Asset> assetMap = new HashMap<>();

  /** Sequence number that used to save asset and tag. */
  private static Integer SEQUENCE = 0;

  /**
   * Returns all assets.
   *
   * @return all assets.
   */
  public List<Asset> getAll() {
    return new ArrayList<>(assetMap.values());
  }

  /**
   * Returns the asset which is associated with given id.
   *
   * @param id key of the association
   * @return the value which is associated with given key, or null if the association not found
   */
  public Asset getById(Integer id) {
    return assetMap.get(id);
  }

  /**
   * Saves given asset.
   *
   * @param asset asset to be saved.
   */
  public void save(Asset asset) {
    Integer assetId = generateId();
    asset.setId(assetId);
    assetMap.put(assetId, asset);
  }

  /**
   * Updates given asset.
   *
   * @param asset asset to be updated
   */
  public void update(Asset asset) {
    assetMap.put(asset.getId(), asset);
  }

  /**
   * Deletes given asset.
   *
   * @param asset asset to be deleted
   */
  public void delete(Asset asset) {
    assetMap.remove(asset.getId());
  }

  /** Returns assets whose name contains given string. */
  public List<Asset> searchByName(String name) {
    return getAll().stream()
        .filter(a -> a.getName().toLowerCase().contains(name.toLowerCase()))
        .collect(Collectors.toList());
  }

  /** Returns assets whose type contains given string. */
  public List<Asset> searchByType(String type) {
    return getAll().stream()
        .filter(a -> a.getType().toLowerCase().contains(type.toLowerCase()))
        .collect(Collectors.toList());
  }

  /** Returns assets whose tag contains given string. */
  public List<Asset> searchByTag(String tag) {
    return getAll().stream()
        .filter(
            a -> a.getTags().stream().anyMatch(t -> t.toLowerCase().contains(tag.toLowerCase())))
        .collect(Collectors.toList());
  }

  /** Loads both metadata and asset data in memory. */
  public void loadData() {
    loadMetaData();
    loadAssetData();
  }

  /** Loads metadata from file. */
  private void loadMetaData() {
    String fileContent = FileUtils.read(METADATA_FILE_NAME);

    if (fileContent == null || fileContent.isEmpty()) {
      return;
    }

    Type type = new TypeToken<List<Metadata>>() {}.getType();
    List<Metadata> metadataList = JsonUtils.parse(fileContent, type);

    Metadata metadata =
        metadataList.stream()
            .filter(m -> m.getKey().equals(MetadataConstants.SEQUENCE_CURRENT_VALUE))
            .findFirst()
            .orElse(null);

    if (metadata != null && metadata.getValue() != null) {
      SEQUENCE = Integer.valueOf(metadata.getValue());
    }
  }

  private void loadAssetData() {
    String fileContent = FileUtils.read(ASSETS_FILE_NAME);

    if (fileContent == null || fileContent.isEmpty()) {
      return;
    }

    Type type = new TypeToken<List<Asset>>() {}.getType();
    List<Asset> assets = JsonUtils.parse(fileContent, type);

    assetMap = assets.stream().collect(Collectors.toMap(Asset::getId, Function.identity()));
  }

  /** Flushes both metadata and asset data. */
  public void flush() {
    flushMetadata();
    flushAssetData();
  }

  /** Removes all data. */
  public void cleanUp() {
    SEQUENCE = 0;
    assetMap = new HashMap<>();
    flush();
  }

  /** Flushes metadata to file */
  private void flushMetadata() {
    List<Metadata> metadataList = new ArrayList<>();
    metadataList.add(new Metadata(MetadataConstants.SEQUENCE_CURRENT_VALUE, SEQUENCE.toString()));
    String metadataAsJsonStr = JsonUtils.toJson(metadataList);

    FileUtils.write(METADATA_FILE_NAME, metadataAsJsonStr);
  }

  /** Flushes assets to file. */
  private void flushAssetData() {
    List<Asset> assets = assetMap.values().stream().collect(Collectors.toList());
    String assetsAsJsonStr = JsonUtils.toJson(assets);

    FileUtils.write(ASSETS_FILE_NAME, assetsAsJsonStr);
  }

  /**
   * Generates a unique identifier.
   *
   * @return - a unique identifier.
   */
  private Integer generateId() {
    return ++SEQUENCE;
  }
}

package com.example;

/** Driver. */
public class Driver {

  public static void main(String[] args) {
    InputOutputService inputOutputService = new InputOutputService();
    AssetRepository assetRepository = new AssetRepository();
    AssetManager assetManager = new AssetManager(inputOutputService, assetRepository);
    assetManager.run(args);
  }
}

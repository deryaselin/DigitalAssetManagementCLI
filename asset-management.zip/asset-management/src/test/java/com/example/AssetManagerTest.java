package com.example;

import com.example.model.Asset;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

public class AssetManagerTest {

  InputOutputService inputOutputService = new InputOutputService();

  AssetRepository assetRepository = new AssetRepository();

  AssetManager cut = new AssetManager(inputOutputService, assetRepository);

  @BeforeEach
  void beforeEach() {
    assetRepository.cleanUp();
  }

  @Test
  void shouldNotSaveAssetWhenAssetNameIsNotProvided() {
    String argStr = "-command save -type Voice -tags Tag-1 Tag-2";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(0, allAssets.size());
  }

  @Test
  void shouldNotSaveAssetWhenAssetTypeIsNotProvided() {
    String argStr = "-command save -name Asset-1 -tags Tag-1 Tag-2";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(0, allAssets.size());
  }

  @Test
  void shouldSaveAssetSuccessfully() {
    String argStr = "-command save -name Asset-1 -type Voice -tags Tag-1 Tag-2";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
    Assertions.assertEquals("Asset-1", allAssets.get(0).getName());
    Assertions.assertEquals("Voice", allAssets.get(0).getType());
    Assertions.assertEquals(List.of("Tag-1", "Tag-2"), allAssets.get(0).getTags());
  }

  @Test
  void shouldNotUpdateAssetWhenAssetIdIsNotProvided() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command update -name Update-Asset";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
    Assertions.assertEquals("Asset-1", allAssets.get(0).getName());
  }

  @Test
  void shouldUpdateAssetNameSuccessfully() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command update -id 1 -name Updated-Asset";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
    Assertions.assertEquals("Updated-Asset", allAssets.get(0).getName());
    Assertions.assertEquals("Voice", allAssets.get(0).getType());
    Assertions.assertEquals(List.of("Tag-1", "Tag-2"), allAssets.get(0).getTags());
  }

  @Test
  void shouldUpdateAssetTypeSuccessfully() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command update -id 1 -type Image";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
    Assertions.assertEquals("Asset-1", allAssets.get(0).getName());
    Assertions.assertEquals("Image", allAssets.get(0).getType());
    Assertions.assertEquals(List.of("Tag-1", "Tag-2"), allAssets.get(0).getTags());
  }

  @Test
  void shouldUpdateAssetTagsSuccessfully() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command update -id 1 -tags Tag-3";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
    Assertions.assertEquals("Asset-1", allAssets.get(0).getName());
    Assertions.assertEquals("Voice", allAssets.get(0).getType());
    Assertions.assertEquals(List.of("Tag-3"), allAssets.get(0).getTags());
  }

  @Test
  void shouldNotDeleteAssetWhenAssetIdIsNotProvided() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command delete";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(1, allAssets.size());
  }

  @Test
  void shouldDeleteAssetSuccessfully() {
    Asset asset = new Asset();
    asset.setName("Asset-1");
    asset.setType("Voice");
    asset.setTags(List.of("Tag-1", "Tag-2"));

    assetRepository.save(asset);
    assetRepository.flush();

    String argStr = "-command delete -id 1";
    String[] args = argStr.split(" ");

    cut.run(args);

    List<Asset> allAssets = assetRepository.getAll();

    Assertions.assertEquals(0, allAssets.size());
  }
}

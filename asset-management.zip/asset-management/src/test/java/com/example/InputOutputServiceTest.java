package com.example;

import com.example.enums.CommandType;
import com.example.enums.SearchType;
import com.example.model.Command;
import org.apache.commons.cli.ParseException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class InputOutputServiceTest {

  InputOutputService cut = new InputOutputService();

  @Test
  void shouldParseNameTypeAndTagsSuccessfullyWhenCommandIsSave() {
    String argStr = "-command save -name Asset-1 -type Voice -tags Tag-1 Tag-2";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.SAVE, result.getCommandType());
    Assertions.assertEquals("Asset-1", result.getName());
    Assertions.assertEquals("Voice", result.getType());
    Assertions.assertArrayEquals(new String[] {"Tag-1", "Tag-2"}, result.getTags());
  }

  @Test
  void shouldParseNameTypeAndTagsSuccessfullyWhenCommandIsUpdate() {
    String argStr = "-command update -name Asset-1 -type Voice -tags Tag-1 Tag-2";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.UPDATE, result.getCommandType());
    Assertions.assertEquals("Asset-1", result.getName());
    Assertions.assertEquals("Voice", result.getType());
    Assertions.assertArrayEquals(new String[] {"Tag-1", "Tag-2"}, result.getTags());
  }

  @Test
  void shouldParseIdSuccessfullyWhenCommandIsDelete() {
    String argStr = "-command delete -id 5";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.DELETE, result.getCommandType());
    Assertions.assertEquals(5, result.getId());
  }

  @Test
  void shouldParseSearchCriteriaAndSearchValueSuccessfullyWhenCommandIsSearch()
      throws ParseException {
    String argStr = "-command search -search-criteria type -search-value Voice";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.SEARCH, result.getCommandType());
    Assertions.assertEquals(SearchType.BY_TYPE, result.getSearchType());
    Assertions.assertEquals("Voice", result.getSearchValue());
  }

  @Test
  void shouldParseCommandTypeSuccessfullyWhenCommandIsList() {
    String argStr = "-command list";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.LIST, result.getCommandType());
  }

  @Test
  void shouldParseCommandTypeSuccessfullyWhenCommandIsHelp() {
    String argStr = "-command help";
    String[] args = argStr.split(" ");

    Command result = cut.parse(args);

    Assertions.assertNotNull(result);
    Assertions.assertEquals(CommandType.HELP, result.getCommandType());
  }
}
